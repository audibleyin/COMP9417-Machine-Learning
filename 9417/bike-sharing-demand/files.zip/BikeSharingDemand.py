import pandas as pd
import numpy as np
from matplotlib.gridspec import GridSpec
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
import warnings
import matplotlib.pyplot as plt
import seaborn as sn
warnings.filterwarnings('ignore')


def get_rmsle(y_pred, y_actual):
    # using RMSLE to evaluate the model
    diff = np.log(y_pred + 1) - np.log(y_actual + 1)
    mean_error = np.square(diff).mean()
    return np.sqrt(mean_error)

# read dataset
train_df = pd.read_csv("train.csv", header=0,parse_dates=['datetime'])
test_df = pd.read_csv("test.csv", header=0)

# features selection
selected_features = ['datetime', 'season', 'holiday', 'workingday', 'weather', 'temp', 'humidity', 'casual',
                     'registered', 'count']
test_selected_features = ['datetime', 'season', 'holiday', 'workingday', 'weather', 'temp', 'humidity']

X_train_df = train_df[selected_features]
for col in ['casual', 'registered', 'count']:
    X_train_df['%s_log' % col] = np.log(X_train_df[col] + 1)
# print(X_train_df.columns)
X_test_df = test_df[test_selected_features]
X_train_df1 = train_df[test_selected_features]
X_train_df0 = train_df[selected_features]

# features processing
X_train_df0['month'] = pd.DatetimeIndex(X_train_df.datetime).month
X_train_df0['day'] = pd.DatetimeIndex(X_train_df.datetime).dayofweek
X_train_df0['hour'] = pd.DatetimeIndex(X_train_df.datetime).hour
X_train_df0['woy'] = pd.DatetimeIndex(X_train_df.datetime).weekofyear

X_train_df['month'] = pd.DatetimeIndex(X_train_df.datetime).month
X_train_df['day'] = pd.DatetimeIndex(X_train_df.datetime).dayofweek
X_train_df['hour'] = pd.DatetimeIndex(X_train_df.datetime).hour
X_train_df['woy'] = pd.DatetimeIndex(X_train_df.datetime).weekofyear
X_train_df = X_train_df.drop(['datetime'], axis=1)
X_train_df = X_train_df.drop(['casual'], axis=1)
X_train_df = X_train_df.drop(['registered'], axis=1)
X_train_df = X_train_df.drop(['count'], axis=1)
X_test_df['month'] = pd.DatetimeIndex(X_test_df.datetime).month
X_test_df['day'] = pd.DatetimeIndex(X_test_df.datetime).dayofweek
X_test_df['hour'] = pd.DatetimeIndex(X_test_df.datetime).hour
X_test_df['woy'] = pd.DatetimeIndex(X_test_df.datetime).weekofyear
X_test_df = X_test_df.drop(['datetime'], axis=1)
X_train_df1['month'] = pd.DatetimeIndex(X_train_df1.datetime).month
X_train_df1['day'] = pd.DatetimeIndex(X_train_df1.datetime).dayofweek
X_train_df1['hour'] = pd.DatetimeIndex(X_train_df1.datetime).hour
X_train_df1['woy'] = pd.DatetimeIndex(X_train_df1.datetime).weekofyear
X_train_df1 = X_train_df1.drop(['datetime'], axis=1)

# show Features Correlation
corrMatrix=X_train_df0.corr()

# Visualize the correlation coefficient matrix
mask=np.array(corrMatrix)
mask[np.tril_indices_from(mask)] = False
fig,ax=plt.subplots()
fig.set_size_inches(10,8)
sn.heatmap(corrMatrix,mask=mask,vmax=0.8,square=True,annot=True,)
# plt.show()
# Rental status per hour per year
def plot_by_hour(data, year=None, agg='sum'):
    dd = data.copy()
    if year: dd = dd[dd.datetime.dt.year == year]
    dd.loc[:, ('hour')] = dd.datetime.dt.hour

    by_hour = dd.groupby(['hour', 'workingday'])['count'].agg(agg).unstack()
    return by_hour.plot(kind='line', title="Year = {0}".format(year))


plot_by_hour(train_df, year=2011)
plot_by_hour(train_df, year=2012)

fig,axes=plt.subplots(2,2)
fig.set_size_inches(9, 9)

# Unified delivery box chart to show the relation between count and features
ax1 = sn.boxplot(data=X_train_df0, y='count', x='season', orient='v', ax=axes[0][0])
ax2 = sn.boxplot(data=X_train_df0, y='count', x='holiday', orient='v', ax=axes[0][1])
ax3 = sn.boxplot(data=X_train_df0, y='count', x='workingday', orient='v', ax=axes[1][0])
ax4 = sn.boxplot(data=X_train_df0, y='count', x='weather', orient='v', ax=axes[1][1])
plt.show()
#  Monthly distribution of counts
fig, ax = plt.subplots()
sn.barplot(data=X_train_df0[['month', 'count']], x='month', y='count')
ax.set(title='monthly distribution of counts ')
# plt.show()



# the target variables registered and casual are converted into log(a+1) form
plt.hist(train_df.registered,bins=50)
plt.hist(np.log(train_df.registered+1),bins=50)
plt.hist(train_df.casual,bins=50)
plt.hist(np.log(train_df.casual+1),bins=50)
plt.show()

# compare the impact of different humidity on the number of rentals
windspeed_show = train_df.groupby(['windspeed'], as_index=True).agg({'casual': 'max',
                                                                        'registered': 'max',
                                                                        'count': 'max'})
windspeed_show.plot(title='relationship between windspeed and number of users')
# humidity
# higher humidity ,less number of users
fig = plt.figure(figsize=(10, 10))
gs1 = GridSpec(4, 4, fig, wspace=0.5, hspace=0.5)
plt.subplot(gs1[:2, 1:3])
sn.regplot(x='humidity', y='count', data=X_train_df0,
            line_kws={"color":"black", "linewidth":2})
plt.subplot(gs1[2:, :2])
sn.regplot(x='humidity', y='casual', data=X_train_df0,
            line_kws={"color":"black", "linewidth":2})
plt.subplot(gs1[2:, 2:])
sn.regplot(x='humidity', y='registered', data=X_train_df0,
            line_kws={"color":"black", "linewidth":2})

#exploratory analys on atemp vs temp
fig, axes = plt.subplots(figsize = (10, 5))
temperature = train_df[['temp', 'atemp']]
axes.scatter(temperature.temp, temperature.atemp)
plt.title('temp vs atemp')
axes.set_xlabel ('temp')
axes.set_ylabel('atemp')

# using svr model to test dataset, and obtain RMSLE result
SVR = SVR()
SVR.fit(X_train_df1,X_train_df['casual_log'])
SVR_casual_predict_train = SVR.predict(X_train_df1)
SVR_casual_predict_train = np.exp(SVR_casual_predict_train) - 1
SVR_casual_predict_train[SVR_casual_predict_train < 0] = 0
SVR_casual_predict = SVR.predict(X_test_df)
SVR_casual_predict = np.exp(SVR_casual_predict) - 1
SVR_casual_predict[SVR_casual_predict < 0] = 0
SVR.fit(X_train_df1,X_train_df['registered_log'])
SVR_registered_predict_train = SVR.predict(X_train_df1)
SVR_registered_predict_train = np.exp(SVR_registered_predict_train) - 1
SVR_registered_predict_train[SVR_registered_predict_train < 0] = 0
SVR_registered_predict = SVR.predict(X_test_df)
SVR_registered_predict = np.exp(SVR_registered_predict) - 1
SVR_registered_predict[SVR_registered_predict < 0] = 0
SVR_trian_preds=SVR_casual_predict_train + SVR_registered_predict_train
SVR_preds = SVR_casual_predict +SVR_registered_predict

# using Random forest model to test dataset, and obtain RMSLE result
rf = RandomForestRegressor(n_estimators=1000,max_depth =15 ,random_state=0)
rf.fit(X_train_df1, X_train_df['casual_log'])
rf_casual_predict_train = rf.predict(X_train_df1)
rf_casual_predict_train = np.exp(rf_casual_predict_train) - 1
rf_casual_predict_train[rf_casual_predict_train < 0] = 0
rf_casual_predict = rf.predict(X_test_df)
rf_casual_predict = np.exp(rf_casual_predict) - 1
rf_casual_predict[rf_casual_predict < 0] = 0
rf.fit(X_train_df1, X_train_df['registered_log'])
rf_registered_predict_train = rf.predict(X_train_df1)
rf_registered_predict_train = np.exp(rf_registered_predict_train) - 1
rf_registered_predict_train[rf_registered_predict_train < 0] = 0
rf_registered_predict = rf.predict(X_test_df)
rf_registered_predict = np.exp(rf_registered_predict) - 1
rf_registered_predict[rf_registered_predict < 0] = 0
rf_trian_preds=np.round(rf_casual_predict_train + rf_registered_predict_train)
rf_preds = np.round(rf_casual_predict + rf_registered_predict)

# using Gradient Boosting Regressor model to test dataset, and obtain RMSLE result
gbr = GradientBoostingRegressor(n_estimators=1000,max_depth =5 ,random_state=0)
gbr.fit(X_train_df1, X_train_df['casual_log'])
gbr_casual_predict_train = gbr.predict(X_train_df1)
gbr_casual_predict_train = np.exp(gbr_casual_predict_train) - 1
gbr_casual_predict_train[gbr_casual_predict_train < 0] = 0
gbr_casual_predict = gbr.predict(X_test_df)
gbr_casual_predict = np.exp(gbr_casual_predict) - 1
gbr_casual_predict[gbr_casual_predict < 0] = 0
gbr.fit(X_train_df1, X_train_df['registered_log'])
gbr_registered_predict_train = gbr.predict(X_train_df1)
gbr_registered_predict_train = np.exp(gbr_registered_predict_train) - 1
gbr_registered_predict_train[gbr_registered_predict_train < 0] = 0
gbr_registered_predict = gbr.predict(X_test_df)
gbr_registered_predict = np.exp(gbr_registered_predict) - 1
gbr_registered_predict[gbr_registered_predict < 0] = 0
gbr_trian_preds=np.round(gbr_casual_predict_train + gbr_registered_predict_train)
gbr_preds = np.round(gbr_casual_predict + gbr_registered_predict)

print(get_rmsle(rf_trian_preds,train_df['count']))
print(get_rmsle(gbr_trian_preds,train_df['count']))
print(get_rmsle(SVR_trian_preds,train_df['count']))

# tuning parameters to mix different model to obtain a better RMSLE result
print(get_rmsle(0.1 * rf_trian_preds + 0.9 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.2 * rf_trian_preds + 0.8 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.3 * rf_trian_preds + 0.7 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.4 * rf_trian_preds + 0.6 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.5 * rf_trian_preds + 0.5 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.6 * rf_trian_preds + 0.4 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.7 * rf_trian_preds + 0.3 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.8 * rf_trian_preds + 0.2 * gbr_trian_preds,train_df['count']))
print(get_rmsle(0.9 * rf_trian_preds + 0.1 * gbr_trian_preds,train_df['count']))
# print result
rf_submission = pd.DataFrame({'datetime': test_df['datetime'], 'count': 0.6 * rf_preds + 0.4 * gbr_preds})
rf_submission.to_csv('final_submission.csv', index=False)
